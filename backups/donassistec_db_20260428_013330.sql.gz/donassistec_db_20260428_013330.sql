-- MySQL dump 10.19  Distrib 10.3.39-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: donassistec_db
-- ------------------------------------------------------
-- Server version	5.7.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_role_modules`
--

DROP TABLE IF EXISTS `admin_role_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_modules` (
  `role` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module_key` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`role`,`module_key`),
  KEY `idx_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_role_modules`
--

LOCK TABLES `admin_role_modules` WRITE;
/*!40000 ALTER TABLE `admin_role_modules` DISABLE KEYS */;
INSERT INTO `admin_role_modules` VALUES ('admin','avaliacoes'),('admin','configuracoes'),('admin','cupons'),('admin','dashboard'),('admin','equipe'),('admin','estoque'),('admin','home-content'),('admin','logs'),('admin','lojistas'),('admin','marcas'),('admin','modelos'),('admin','pedidos'),('admin','pre-pedidos'),('admin','precos-dinamicos'),('admin','relatorios'),('admin','servicos'),('admin','tickets'),('gerente','avaliacoes'),('gerente','configuracoes'),('gerente','cupons'),('gerente','dashboard'),('gerente','estoque'),('gerente','home-content'),('gerente','logs'),('gerente','lojistas'),('gerente','marcas'),('gerente','modelos'),('gerente','pedidos'),('gerente','pre-pedidos'),('gerente','precos-dinamicos'),('gerente','relatorios'),('gerente','servicos'),('gerente','tickets'),('tecnico','dashboard'),('tecnico','estoque'),('tecnico','marcas'),('tecnico','modelos'),('tecnico','pedidos'),('tecnico','pre-pedidos'),('tecnico','servicos'),('user','avaliacoes'),('user','dashboard'),('user','lojistas'),('user','pedidos'),('user','pre-pedidos'),('user','relatorios'),('user','tickets');
/*!40000 ALTER TABLE `admin_role_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_team`
--

DROP TABLE IF EXISTS `admin_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_team` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','gerente','tecnico','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_email` (`email`),
  KEY `idx_role` (`role`),
  KEY `idx_active` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_team`
--

LOCK TABLES `admin_team` WRITE;
/*!40000 ALTER TABLE `admin_team` DISABLE KEYS */;
INSERT INTO `admin_team` VALUES ('ateam-1777296113832-0wsshphc','ronei@donassistec.com','$2b$10$60o4i9zGLUKfNqt0ZeSvNefHlVtQGo9ia0MHNFmyS7LnTlRDN6VJC','Administrador','admin',1,'2026-04-27 13:21:53','2026-04-27 14:23:53'),('ateam-1777299446459-aanhjo4k','dev@donassistec.com','$2b$10$wk4RrFGbwL/Al8xgfMJJFOigOlBYnP4J1pOe7jGawuuzp/bZDLTqa','desenvolvedor','gerente',1,'2026-04-27 14:17:26','2026-04-27 14:17:26'),('ateam-1777299498342-grn1y51f','don@donassistec.com','$2b$10$s2yQ4WwTFir8xSXhQQfTOuzqKY9TLFA0JPTtgUy8i6f9FCC8PZQJ2','donavan','tecnico',1,'2026-04-27 14:18:18','2026-04-27 14:18:18'),('ateam-1777299673042-2t50ujvm','carol@donassistec.com','$2b$10$FtLKIkb4lp5yInkDLil/8.GIbGynJUymG04J8iKEi4BWCRSZEtKFK','user','user',1,'2026-04-27 14:21:13','2026-04-27 14:21:13');
/*!40000 ALTER TABLE `admin_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_user_module_overrides`
--

DROP TABLE IF EXISTS `admin_user_module_overrides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_user_module_overrides` (
  `user_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module_key` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_id`,`module_key`),
  KEY `idx_user` (`user_id`),
  CONSTRAINT `admin_user_module_overrides_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `admin_team` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_user_module_overrides`
--

LOCK TABLES `admin_user_module_overrides` WRITE;
/*!40000 ALTER TABLE `admin_user_module_overrides` DISABLE KEYS */;
INSERT INTO `admin_user_module_overrides` VALUES ('ateam-1777299446459-aanhjo4k','avaliacoes',1),('ateam-1777299446459-aanhjo4k','configuracoes',1),('ateam-1777299446459-aanhjo4k','cupons',1),('ateam-1777299446459-aanhjo4k','dashboard',1),('ateam-1777299446459-aanhjo4k','equipe',0),('ateam-1777299446459-aanhjo4k','estoque',1),('ateam-1777299446459-aanhjo4k','home-content',1),('ateam-1777299446459-aanhjo4k','logs',1),('ateam-1777299446459-aanhjo4k','lojistas',1),('ateam-1777299446459-aanhjo4k','marcas',1),('ateam-1777299446459-aanhjo4k','modelos',1),('ateam-1777299446459-aanhjo4k','pedidos',1),('ateam-1777299446459-aanhjo4k','pre-pedidos',1),('ateam-1777299446459-aanhjo4k','precos-dinamicos',1),('ateam-1777299446459-aanhjo4k','relatorios',1),('ateam-1777299446459-aanhjo4k','servicos',1),('ateam-1777299446459-aanhjo4k','tabela-precos',1),('ateam-1777299446459-aanhjo4k','tickets',1),('ateam-1777299446459-aanhjo4k','videos-lojista',1),('ateam-1777299498342-grn1y51f','avaliacoes',1),('ateam-1777299498342-grn1y51f','configuracoes',0),('ateam-1777299498342-grn1y51f','cupons',1),('ateam-1777299498342-grn1y51f','dashboard',1),('ateam-1777299498342-grn1y51f','equipe',0),('ateam-1777299498342-grn1y51f','estoque',1),('ateam-1777299498342-grn1y51f','home-content',0),('ateam-1777299498342-grn1y51f','logs',1),('ateam-1777299498342-grn1y51f','lojistas',1),('ateam-1777299498342-grn1y51f','marcas',1),('ateam-1777299498342-grn1y51f','modelos',1),('ateam-1777299498342-grn1y51f','pedidos',1),('ateam-1777299498342-grn1y51f','pre-pedidos',1),('ateam-1777299498342-grn1y51f','precos-dinamicos',1),('ateam-1777299498342-grn1y51f','relatorios',1),('ateam-1777299498342-grn1y51f','servicos',1),('ateam-1777299498342-grn1y51f','tabela-precos',1),('ateam-1777299498342-grn1y51f','tickets',1),('ateam-1777299498342-grn1y51f','videos-lojista',1),('ateam-1777299673042-2t50ujvm','avaliacoes',1),('ateam-1777299673042-2t50ujvm','configuracoes',0),('ateam-1777299673042-2t50ujvm','cupons',0),('ateam-1777299673042-2t50ujvm','dashboard',1),('ateam-1777299673042-2t50ujvm','equipe',0),('ateam-1777299673042-2t50ujvm','estoque',0),('ateam-1777299673042-2t50ujvm','home-content',0),('ateam-1777299673042-2t50ujvm','logs',0),('ateam-1777299673042-2t50ujvm','lojistas',1),('ateam-1777299673042-2t50ujvm','marcas',0),('ateam-1777299673042-2t50ujvm','modelos',0),('ateam-1777299673042-2t50ujvm','pedidos',0),('ateam-1777299673042-2t50ujvm','pre-pedidos',0),('ateam-1777299673042-2t50ujvm','precos-dinamicos',0),('ateam-1777299673042-2t50ujvm','relatorios',1),('ateam-1777299673042-2t50ujvm','servicos',0),('ateam-1777299673042-2t50ujvm','tabela-precos',1),('ateam-1777299673042-2t50ujvm','tickets',1),('ateam-1777299673042-2t50ujvm','videos-lojista',0);
/*!40000 ALTER TABLE `admin_user_module_overrides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_values` json DEFAULT NULL,
  `new_values` json DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_entity` (`entity_type`,`entity_id`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brands` (
  `id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brands`
--

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES ('apple','Apple','https://cdn.jsdelivr.net/npm/simple-icons@v10/icons/apple.svg','AppleIcon','2026-04-27 12:31:40','2026-04-27 12:31:40'),('huawei','Huawei','https://cdn.jsdelivr.net/npm/simple-icons@v10/icons/huawei.svg','HuaweiIcon','2026-04-27 12:31:40','2026-04-27 12:31:40'),('lg','LG','https://cdn.jsdelivr.net/npm/simple-icons@v10/icons/lg.svg','LgIcon','2026-04-27 12:31:40','2026-04-27 12:31:40'),('motorola','Motorola','https://cdn.jsdelivr.net/npm/simple-icons@v10/icons/motorola.svg','MotorolaIcon','2026-04-27 12:31:40','2026-04-27 12:31:40'),('samsung','Samsung','https://cdn.jsdelivr.net/npm/simple-icons@v10/icons/samsung.svg','SamsungIcon','2026-04-27 12:31:40','2026-04-27 12:31:40'),('xiaomi','Xiaomi','https://cdn.jsdelivr.net/npm/simple-icons@v10/icons/xiaomi.svg','XiaomiIcon','2026-04-27 12:31:40','2026-04-27 12:31:40');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupon_usage`
--

DROP TABLE IF EXISTS `coupon_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupon_usage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `retailer_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount_amount` decimal(10,2) NOT NULL,
  `used_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_coupon` (`coupon_id`),
  KEY `idx_retailer` (`retailer_id`),
  KEY `idx_order` (`order_id`),
  CONSTRAINT `coupon_usage_ibfk_1` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon_usage`
--

LOCK TABLES `coupon_usage` WRITE;
/*!40000 ALTER TABLE `coupon_usage` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupon_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupons` (
  `id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `discount_type` enum('percentage','fixed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'percentage',
  `discount_value` decimal(10,2) NOT NULL,
  `min_order_value` decimal(10,2) DEFAULT '0.00',
  `max_discount` decimal(10,2) DEFAULT NULL,
  `usage_limit` int(11) DEFAULT NULL,
  `used_count` int(11) DEFAULT '0',
  `valid_from` datetime NOT NULL,
  `valid_until` datetime NOT NULL,
  `active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_code` (`code`),
  KEY `idx_active` (`active`),
  KEY `idx_valid_dates` (`valid_from`,`valid_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dynamic_pricing`
--

DROP TABLE IF EXISTS `dynamic_pricing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dynamic_pricing` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `min_quantity` int(11) NOT NULL,
  `max_quantity` int(11) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `discount_percentage` decimal(5,2) DEFAULT '0.00',
  `valid_from` date DEFAULT NULL,
  `valid_until` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_model` (`model_id`),
  KEY `idx_quantity` (`min_quantity`,`max_quantity`),
  CONSTRAINT `dynamic_pricing_ibfk_1` FOREIGN KEY (`model_id`) REFERENCES `phone_models` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dynamic_pricing`
--

LOCK TABLES `dynamic_pricing` WRITE;
/*!40000 ALTER TABLE `dynamic_pricing` DISABLE KEYS */;
/*!40000 ALTER TABLE `dynamic_pricing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `home_content`
--

DROP TABLE IF EXISTS `home_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `home_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` json NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `section` (`section`),
  KEY `idx_section` (`section`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `home_content`
--

LOCK TABLES `home_content` WRITE;
/*!40000 ALTER TABLE `home_content` DISABLE KEYS */;
INSERT INTO `home_content` VALUES (1,'main','{\"stats\": [{\"id\": \"models\", \"label\": \"Modelos Compatíveis\", \"value\": \"500+\", \"description\": \"Trabalhamos com todas as principais marcas e modelos do mercado.\"}, {\"id\": \"screens\", \"label\": \"Telas Reconstruídas\", \"value\": \"10k+\", \"description\": \"Experiência comprovada em reconstrução de telas.\"}, {\"id\": \"retailers\", \"label\": \"Lojistas Parceiros\", \"value\": \"500+\", \"description\": \"Centenas de lojistas confiam na DonAssistec.\"}, {\"id\": \"satisfaction\", \"label\": \"Satisfação\", \"value\": \"98%\", \"description\": \"Taxa de satisfação dos nossos clientes.\"}, {\"id\": \"warranty\", \"label\": \"Garantia Total\", \"value\": \"90 dias\", \"description\": \"Garantia estendida em todos os produtos.\"}, {\"id\": \"rating\", \"label\": \"Avaliação Média\", \"value\": \"5.0\", \"description\": \"Avaliação média dos nossos serviços.\"}], \"steps\": [{\"id\": \"step-1\", \"href\": \"/catalogo\", \"title\": \"Explore o Catálogo\", \"action\": \"Ver Catálogo\", \"number\": \"01\", \"description\": \"Navegue pelo nosso catálogo completo de modelos e peças disponíveis.\"}, {\"id\": \"step-2\", \"href\": \"#contato\", \"title\": \"Solicite um Orçamento\", \"action\": \"Falar no WhatsApp\", \"number\": \"02\", \"description\": \"Entre em contato via WhatsApp ou e-mail para solicitar um orçamento personalizado.\"}, {\"id\": \"step-3\", \"href\": null, \"title\": \"Receba o Orçamento\", \"action\": null, \"number\": \"03\", \"description\": \"Nossa equipe envia um orçamento detalhado com preços e prazos de entrega.\"}, {\"id\": \"step-4\", \"href\": \"/lojista/login\", \"title\": \"Aprove e Receba\", \"action\": \"Criar Conta\", \"number\": \"04\", \"description\": \"Após aprovação, processamos seu pedido e entregamos no prazo acordado.\"}], \"showCta\": true, \"features\": [{\"id\": \"fast-delivery\", \"title\": \"Entrega Rápida\", \"description\": \"Processamento rápido de pedidos com logística pensada para o dia a dia do lojista.\"}, {\"id\": \"full-warranty\", \"title\": \"Garantia Total\", \"description\": \"90 dias de garantia em todos os produtos e serviços de reconstrução.\"}, {\"id\": \"premium-quality\", \"title\": \"Qualidade Premium\", \"description\": \"Produtos de alta qualidade com rigoroso controle em cada etapa.\"}, {\"id\": \"support-24-7\", \"title\": \"Suporte 24/7\", \"description\": \"Atendimento dedicado para lojistas com suporte contínuo.\"}, {\"id\": \"strategic-partnership\", \"title\": \"Parceria Estratégica\", \"description\": \"Relacionamento de longo prazo com benefícios exclusivos para parceiros.\"}, {\"id\": \"competitive-prices\", \"title\": \"Preços Competitivos\", \"description\": \"Melhores preços do mercado para lojistas e assistências técnicas.\"}], \"showHero\": true, \"heroBadge\": \"Laboratório Premium B2B\", \"heroImage\": \"\", \"heroTitle\": \"Reconstrução de Telas e Peças Premium para Lojistas\", \"showStats\": true, \"heroImages\": [], \"showBrands\": true, \"statsTitle\": \"Resultados que Comprovam\", \"heroCtaLink\": \"/catalogo\", \"showProcess\": true, \"heroCtaLabel\": \"Explorar Catálogo\", \"heroSubtitle\": \"\", \"heroVideoUrl\": \"https://donassistec.com.br/uploads/video-1777298650734-385084184.mp4\", \"homeBrandIds\": [\"apple\", \"lg\", \"motorola\", \"xiaomi\", \"samsung\"], \"processTitle\": \"Como Funciona o Processo?\", \"showFeatures\": true, \"showServices\": true, \"featuresTitle\": \"Por Que Escolher a DonAssistec?\", \"heroMediaType\": \"video\", \"servicesBadge\": \"Nossos Serviços\", \"servicesCards\": [{\"id\": \"screen-repair\", \"badge\": \"Premium\", \"title\": \"Reconstrução de Telas\", \"features\": [\"Vidro OCA Premium\", \"Máquina Laminar\", \"Touch Original\"], \"description\": \"Processo industrial com máquinas de última geração. Tela original reconstruída com vidro novo e garantia completa.\"}, {\"id\": \"glass-replacement\", \"badge\": \"Rápido\", \"title\": \"Troca de Vidro\", \"features\": [\"Vidro Gorilla Glass\", \"Selagem a Vácuo\", \"24h Entrega\"], \"description\": \"Substituição apenas do vidro frontal, mantendo display e touch originais. Economia para seu cliente.\"}, {\"id\": \"parts-resale\", \"badge\": \"B2B\", \"title\": \"Revenda de Peças\", \"features\": [\"Estoque Local\", \"Preços B2B\", \"Garantia 90 dias\"], \"description\": \"Catálogo completo de peças originais e compatíveis premium para assistências técnicas parceiras.\"}], \"servicesImage\": \"\", \"servicesTitle\": \"Laboratório de Alta Precisão\", \"showHeroPanel\": true, \"statsSubtitle\": \"Nossos números mostram a confiança dos lojistas e a qualidade das entregas.\", \"processSubtitle\": \"Um fluxo simples e eficiente para abastecer sua loja com peças e serviços.\", \"featuresSubtitle\": \"Oferecemos os melhores produtos e serviços com os maiores diferenciais do mercado.\", \"servicesSubtitle\": \"Infraestrutura completa para reconstrução de telas e revenda de peças premium para lojistas e assistências técnicas.\", \"showTestimonials\": true, \"heroImageInterval\": 5000, \"showDifferentials\": true, \"servicesHighlights\": [{\"id\": \"machines\", \"label\": \"Máquinas Industriais\", \"value\": \"Equipamentos de Ponta\"}, {\"id\": \"delivery-time\", \"label\": \"Tempo de Entrega\", \"value\": \"24-48 horas\"}, {\"id\": \"warranty\", \"label\": \"Garantia Completa\", \"value\": \"90 dias\"}], \"servicesImageTitle\": \"Tecnologia de Ponta\", \"showHeroPrimaryCta\": true, \"heroSecondaryCtaLink\": \"/lojista/login\", \"showHeroSecondaryCta\": true, \"heroSecondaryCtaLabel\": \"Área do Lojista\", \"servicesImageDescription\": \"Máquinas de reconstrução mais sofisticadas do mercado brasileiro, garantindo qualidade original nas telas reconstruídas.\"}','2026-04-27 12:41:44','2026-04-27 14:14:09');
/*!40000 ALTER TABLE `home_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_services`
--

DROP TABLE IF EXISTS `model_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_services` (
  `id` varchar(255) NOT NULL,
  `model_id` varchar(100) NOT NULL,
  `service_id` varchar(255) NOT NULL,
  `price` decimal(10,2) DEFAULT '0.00',
  `available` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_model_service` (`model_id`,`service_id`),
  KEY `idx_model_services_model` (`model_id`),
  KEY `idx_model_services_service` (`service_id`),
  KEY `idx_model_services_available` (`available`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_services`
--

LOCK TABLES `model_services` WRITE;
/*!40000 ALTER TABLE `model_services` DISABLE KEYS */;
INSERT INTO `model_services` VALUES ('ms_edge-40-pro_service_glass','edge-40-pro','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_edge-40-pro_service_parts','edge-40-pro','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_edge-40-pro_service_reconstruction','edge-40-pro','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-a34_service_glass','galaxy-a34','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-a34_service_parts','galaxy-a34','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-a34_service_reconstruction','galaxy-a34','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-a54_service_glass','galaxy-a54','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-a54_service_parts','galaxy-a54','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-a54_service_reconstruction','galaxy-a54','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-s23-ultra_service_glass','galaxy-s23-ultra','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-s23-ultra_service_parts','galaxy-s23-ultra','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-s23-ultra_service_reconstruction','galaxy-s23-ultra','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-s23_service_glass','galaxy-s23','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-s23_service_parts','galaxy-s23','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-s23_service_reconstruction','galaxy-s23','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-s24-plus_service_glass','galaxy-s24-plus','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-s24-plus_service_parts','galaxy-s24-plus','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-s24-plus_service_reconstruction','galaxy-s24-plus','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-s24-ultra_service_glass','galaxy-s24-ultra','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-s24-ultra_service_parts','galaxy-s24-ultra','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-s24-ultra_service_reconstruction','galaxy-s24-ultra','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-s24_service_glass','galaxy-s24','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-s24_service_parts','galaxy-s24','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-s24_service_reconstruction','galaxy-s24','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-z-flip-5_service_parts','galaxy-z-flip-5','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_galaxy-z-fold-5_service_parts','galaxy-z-fold-5','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_huawei-nova-12_service_glass','huawei-nova-12','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_huawei-nova-12_service_parts','huawei-nova-12','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_huawei-nova-12_service_reconstruction','huawei-nova-12','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_huawei-p60-pro_service_glass','huawei-p60-pro','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_huawei-p60-pro_service_parts','huawei-p60-pro','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_huawei-p60-pro_service_reconstruction','huawei-p60-pro','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-12_service_glass','iphone-12','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-12_service_parts','iphone-12','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-12_service_reconstruction','iphone-12','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-13-pro-max_service_glass','iphone-13-pro-max','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-13-pro-max_service_parts','iphone-13-pro-max','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-13-pro-max_service_reconstruction','iphone-13-pro-max','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-13_service_glass','iphone-13','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-13_service_parts','iphone-13','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-13_service_reconstruction','iphone-13','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-14-pro-max_service_glass','iphone-14-pro-max','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-14-pro-max_service_parts','iphone-14-pro-max','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-14-pro-max_service_reconstruction','iphone-14-pro-max','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-14_service_glass','iphone-14','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-14_service_parts','iphone-14','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-14_service_reconstruction','iphone-14','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-15-pro-max_service_glass','iphone-15-pro-max','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-15-pro-max_service_parts','iphone-15-pro-max','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-15-pro-max_service_reconstruction','iphone-15-pro-max','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-15-pro_service_glass','iphone-15-pro','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-15-pro_service_parts','iphone-15-pro','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-15-pro_service_reconstruction','iphone-15-pro','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-15_service_glass','iphone-15','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-15_service_parts','iphone-15','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_iphone-15_service_reconstruction','iphone-15','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_lg-k62_service_glass','lg-k62','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_lg-k62_service_parts','lg-k62','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_lg-velvet_service_glass','lg-velvet','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_lg-velvet_service_parts','lg-velvet','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_moto-g54_service_glass','moto-g54','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_moto-g54_service_parts','moto-g54','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_moto-g54_service_reconstruction','moto-g54','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_moto-g73_service_glass','moto-g73','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_moto-g73_service_parts','moto-g73','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_moto-g73_service_reconstruction','moto-g73','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_moto-g84_service_glass','moto-g84','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_moto-g84_service_parts','moto-g84','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_moto-g84_service_reconstruction','moto-g84','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_moto-razr-40_service_parts','moto-razr-40','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_poco-x6_service_glass','poco-x6','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_poco-x6_service_parts','poco-x6','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_poco-x6_service_reconstruction','poco-x6','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_redmi-note-13-pro_service_glass','redmi-note-13-pro','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_redmi-note-13-pro_service_parts','redmi-note-13-pro','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_redmi-note-13-pro_service_reconstruction','redmi-note-13-pro','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_redmi-note-13_service_glass','redmi-note-13','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_redmi-note-13_service_parts','redmi-note-13','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_redmi-note-13_service_reconstruction','redmi-note-13','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_xiaomi-14-ultra_service_glass','xiaomi-14-ultra','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_xiaomi-14-ultra_service_parts','xiaomi-14-ultra','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_xiaomi-14-ultra_service_reconstruction','xiaomi-14-ultra','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_xiaomi-14_service_glass','xiaomi-14','service_glass',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_xiaomi-14_service_parts','xiaomi-14','service_parts',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43'),('ms_xiaomi-14_service_reconstruction','xiaomi-14','service_reconstruction',0.00,1,'2026-04-27 12:31:43','2026-04-27 12:31:43');
/*!40000 ALTER TABLE `model_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_videos`
--

DROP TABLE IF EXISTS `model_videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumbnail_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_order` int(11) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_model` (`model_id`),
  CONSTRAINT `model_videos_ibfk_1` FOREIGN KEY (`model_id`) REFERENCES `phone_models` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_videos`
--

LOCK TABLES `model_videos` WRITE;
/*!40000 ALTER TABLE `model_videos` DISABLE KEYS */;
INSERT INTO `model_videos` VALUES (1,'iphone-15-pro-max','ReconstruÃ§Ã£o de Tela iPhone 15 Pro Max','https://www.youtube.com/embed/dQw4w9WgXcQ','https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400&q=80','5:30',1,'2026-04-27 12:31:40'),(2,'iphone-15-pro-max','Troca de Vidro - Tutorial Completo','https://www.youtube.com/embed/dQw4w9WgXcQ','https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400&q=80','8:15',2,'2026-04-27 12:31:40'),(3,'galaxy-s24-ultra','ReconstruÃ§Ã£o de Tela Galaxy S24 Ultra','https://www.youtube.com/embed/dQw4w9WgXcQ','https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400&q=80','6:20',1,'2026-04-27 12:31:40'),(4,'redmi-note-13-pro','ReconstruÃ§Ã£o Redmi Note 13 Pro','https://www.youtube.com/embed/dQw4w9WgXcQ','https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400&q=80','6:10',1,'2026-04-27 12:31:40'),(5,'redmi-note-13-pro','Troca de Vidro - Tutorial Completo','https://www.youtube.com/embed/dQw4w9WgXcQ','https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400&q=80','8:30',2,'2026-04-27 12:31:40');
/*!40000 ALTER TABLE `model_videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `reconstruction` tinyint(1) DEFAULT '0',
  `glass_replacement` tinyint(1) DEFAULT '0',
  `parts_available` tinyint(1) DEFAULT '0',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_order` (`order_id`),
  KEY `idx_model` (`model_id`),
  CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `retailer_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnpj` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `status` enum('pending','processing','completed','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `total` decimal(10,2) DEFAULT '0.00',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `pre_pedido_id` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_orders_numero` (`numero`),
  KEY `idx_retailer` (`retailer_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created` (`created_at`),
  KEY `idx_orders_pre_pedido_id` (`pre_pedido_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phone_models`
--

DROP TABLE IF EXISTS `phone_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phone_models` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `availability` enum('in_stock','order','out_of_stock') COLLATE utf8mb4_unicode_ci DEFAULT 'in_stock',
  `premium` tinyint(1) DEFAULT '0',
  `popular` tinyint(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `stock_quantity` int(11) DEFAULT '0',
  `min_stock_level` int(11) DEFAULT '5',
  PRIMARY KEY (`id`),
  KEY `idx_brand` (`brand_id`),
  KEY `idx_popular` (`popular`),
  KEY `idx_premium` (`premium`),
  KEY `idx_availability` (`availability`),
  KEY `idx_stock` (`stock_quantity`),
  CONSTRAINT `phone_models_ibfk_1` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phone_models`
--

LOCK TABLES `phone_models` WRITE;
/*!40000 ALTER TABLE `phone_models` DISABLE KEYS */;
INSERT INTO `phone_models` VALUES ('edge-40-pro','motorola','Edge 40 Pro','https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&q=80','https://www.youtube.com/embed/dQw4w9WgXcQ','in_stock',1,1,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('galaxy-a34','samsung','Galaxy A34 5G','https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400&q=80',NULL,'in_stock',0,0,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('galaxy-a54','samsung','Galaxy A54 5G','https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400&q=80','https://www.youtube.com/embed/dQw4w9WgXcQ','in_stock',0,1,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('galaxy-s23','samsung','Galaxy S23','https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400&q=80',NULL,'in_stock',0,1,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('galaxy-s23-ultra','samsung','Galaxy S23 Ultra','https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400&q=80','https://www.youtube.com/embed/dQw4w9WgXcQ','in_stock',0,1,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('galaxy-s24','samsung','Galaxy S24','https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400&q=80',NULL,'in_stock',1,1,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('galaxy-s24-plus','samsung','Galaxy S24+','https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400&q=80',NULL,'in_stock',1,0,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('galaxy-s24-ultra','samsung','Galaxy S24 Ultra','https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400&q=80','https://www.youtube.com/embed/dQw4w9WgXcQ','in_stock',1,1,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('galaxy-z-flip-5','samsung','Galaxy Z Flip 5','https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400&q=80',NULL,'order',1,0,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('galaxy-z-fold-5','samsung','Galaxy Z Fold 5','https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400&q=80',NULL,'order',1,0,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('huawei-nova-12','huawei','Huawei Nova 12','https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400&q=80',NULL,'in_stock',0,0,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('huawei-p60-pro','huawei','Huawei P60 Pro','https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400&q=80',NULL,'order',1,0,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('iphone-12','apple','iPhone 12','https://images.unsplash.com/photo-1611472173362-3f53dbd65d80?w=400&q=80',NULL,'in_stock',0,0,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('iphone-13','apple','iPhone 13','https://images.unsplash.com/photo-1632633173522-47456de71b76?w=400&q=80',NULL,'in_stock',0,1,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('iphone-13-pro-max','apple','iPhone 13 Pro Max','https://images.unsplash.com/photo-1632633173522-47456de71b76?w=400&q=80','https://www.youtube.com/embed/dQw4w9WgXcQ','in_stock',0,1,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('iphone-14','apple','iPhone 14','https://images.unsplash.com/photo-1678685888221-cda773a3dcdb?w=400&q=80',NULL,'in_stock',0,1,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('iphone-14-pro-max','apple','iPhone 14 Pro Max','https://images.unsplash.com/photo-1678685888221-cda773a3dcdb?w=400&q=80',NULL,'in_stock',1,1,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('iphone-15','apple','iPhone 15','https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400&q=80',NULL,'in_stock',0,1,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('iphone-15-pro','apple','iPhone 15 Pro','https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400&q=80',NULL,'in_stock',1,1,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('iphone-15-pro-max','apple','iPhone 15 Pro Max','https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400&q=80','https://www.youtube.com/embed/dQw4w9WgXcQ','in_stock',1,1,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('lg-k62','lg','LG K62','https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&q=80',NULL,'order',0,0,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('lg-velvet','lg','LG Velvet','https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&q=80',NULL,'order',0,0,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('moto-g54','motorola','Moto G54','https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&q=80',NULL,'in_stock',0,0,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('moto-g73','motorola','Moto G73 5G','https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&q=80','https://www.youtube.com/embed/dQw4w9WgXcQ','in_stock',0,1,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('moto-g84','motorola','Moto G84 5G','https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&q=80','https://www.youtube.com/embed/dQw4w9WgXcQ','in_stock',0,1,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('moto-razr-40','motorola','Moto Razr 40','https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&q=80',NULL,'order',1,0,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('poco-x6','xiaomi','POCO X6','https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400&q=80',NULL,'in_stock',0,0,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('redmi-note-13','xiaomi','Redmi Note 13','https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400&q=80',NULL,'in_stock',0,1,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('redmi-note-13-pro','xiaomi','Redmi Note 13 Pro','https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400&q=80','https://www.youtube.com/embed/dQw4w9WgXcQ','in_stock',0,1,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('xiaomi-14','xiaomi','Xiaomi 14','https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400&q=80','https://www.youtube.com/embed/dQw4w9WgXcQ','in_stock',1,1,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5),('xiaomi-14-ultra','xiaomi','Xiaomi 14 Ultra','https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400&q=80','https://www.youtube.com/embed/dQw4w9WgXcQ','in_stock',1,1,'2026-04-27 12:31:40','2026-04-27 12:31:40',0,5);
/*!40000 ALTER TABLE `phone_models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pre_pedidos`
--

DROP TABLE IF EXISTS `pre_pedidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pre_pedidos` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `items_json` json NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `contact_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `is_urgent` tinyint(1) NOT NULL DEFAULT '0',
  `retailer_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `need_by` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pre_pedidos_numero` (`numero`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pre_pedidos`
--

LOCK TABLES `pre_pedidos` WRITE;
/*!40000 ALTER TABLE `pre_pedidos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pre_pedidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_reviews`
--

DROP TABLE IF EXISTS `product_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_reviews` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `retailer_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` int(11) NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `approved` tinyint(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_model` (`model_id`),
  KEY `idx_retailer` (`retailer_id`),
  KEY `idx_approved` (`approved`),
  CONSTRAINT `product_reviews_ibfk_1` FOREIGN KEY (`model_id`) REFERENCES `phone_models` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_reviews`
--

LOCK TABLES `product_reviews` WRITE;
/*!40000 ALTER TABLE `product_reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_view_stats`
--

DROP TABLE IF EXISTS `product_view_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_view_stats` (
  `model_id` varchar(100) NOT NULL,
  `total_views` int(11) DEFAULT '0',
  `unique_views` int(11) DEFAULT '0',
  `last_viewed_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`model_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_view_stats`
--

LOCK TABLES `product_view_stats` WRITE;
/*!40000 ALTER TABLE `product_view_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_view_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_views`
--

DROP TABLE IF EXISTS `product_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_views` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_id` varchar(100) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `viewed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `session_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_product_views_model` (`model_id`),
  KEY `idx_product_views_user` (`user_id`),
  KEY `idx_product_views_date` (`viewed_at`),
  KEY `idx_product_views_session` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_views`
--

LOCK TABLES `product_views` WRITE;
/*!40000 ALTER TABLE `product_views` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `retailer_price_tables`
--

DROP TABLE IF EXISTS `retailer_price_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `retailer_price_tables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `effective_date` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visible_to_retailers` tinyint(1) NOT NULL DEFAULT '1',
  `featured_to_retailers` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `raw_text` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parsed_data` json NOT NULL,
  `service_templates` json DEFAULT NULL,
  `changed_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `change_reason` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `retailer_price_tables`
--

LOCK TABLES `retailer_price_tables` WRITE;
/*!40000 ALTER TABLE `retailer_price_tables` DISABLE KEYS */;
INSERT INTO `retailer_price_tables` VALUES (1,'tabela-vidros','Tabela dos Vidros','27/04/2026',1,0,1,'LISTA DE VEDAÇÃO\n⬜\nIPhone 12  =  R$100,00\nIPhone 12PM  =  R$100,00\nIPhone 13  =  R$100,00\nIPhone 13 Pro  =  R$100,00\nIPhone 13PM  =  R$100,00\nIPhone 14  =  R$100,00\nIPhone 14 Pro  =  R$100,00\nIPhone 14PM  =  R$100,00\nIPhone 15  =  R$100,00\nIPhone 15 Pro  =  R$100,00\nIPhone 15PM  =  R$100,00\nIPhone 16 Pro  =  R$100,00\nIPhone 16PM  =  R$100,00\nIPhone 17 Pro  =  R$100,00\nIPhone 17PM  =  R$100,00\n','{\"intro\": [\"⬜\"], \"title\": \"Tabela dos Vidros\", \"brands\": [{\"name\": \"Geral\", \"devices\": [{\"name\": \"IPhone 12\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 12PM\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 13\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 13 Pro\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 13PM\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 14\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 14 Pro\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 14PM\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 15\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 15 Pro\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 15PM\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 16 Pro\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 16PM\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 17 Pro\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 17PM\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}]}], \"categories\": [{\"name\": \"Geral\", \"items\": [{\"name\": \"IPhone 12\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 12PM\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 13\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 13 Pro\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 13PM\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 14\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 14 Pro\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 14PM\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 15\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 15 Pro\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 15PM\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 16 Pro\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 16PM\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 17 Pro\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 17PM\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}], \"effectiveDate\": \"27/04/2026\"}','[]',NULL,NULL,'2026-04-27 13:51:44','2026-04-27 15:16:40'),(2,'lista-de-tampas-10-04-26','Lista de Tampas','10/04/26',1,0,2,'Lista de Tampas: 10/04/26\n✔️\nIPhone X preto - similar = R$35,00\nIPhone XS preto - similar = R$35,00\nIPhone XS gold - similar = R$35,00\nIPhone XS branco - similar = R$35,00\nIPhone XS MAX gold - similar = R$35,00\nIPhone XS MAX preto - similar = R$35,00\nIPhone XS MAX branco - similar = R$35,00\nIPhone XR preto - similar = R$35,00\nIPhone XR azul - similar = R$35,00\nIPhone XR vermelho - similar = R$35,00\nIPhone XR laranja - similar = R$35,00\nIPhone 8 gold - similar = R$35,00\nIPhone 8 branco - similar = R$35,00\nIPhone 8 preto - similar = R$35,00\nIPhone 8 vermelho - similar = R$35,00\nIPhone 8 plus gold - similar = R$35,00\nIPhone 8 plus branco - similar = R$35,00\nIPhone 8 plus vermelho - similar = R$35,00\nIPhone 8 plus preto - similar = R$35,00\nIPhone SE vermelho - similar = R$35,00\nIPhone SE preto - similar = R$35,00\nIPhone SE branco - similar = R$35,00\nIPhone 11 branco - similar = R$35,00\nIPhone 11 preto - similar = R$35,00\nIPhone 11 verde - similar = R$35,00\nIPhone 11 amarelo - similar = R$35,00\nIPhone 11 lilás - similar = R$35,00\nIPhone 11 vermelho - similar = R$35,00\nIPhone 11 Pro branco - similar = R$45,00\nIPhone 11 Pro preto - similar = R$45,00\nIPhone 11 Pro verde - similar = R$45,00\nIPhone 11 Pro gold - similar = R$45,00\nIPhone 11PM branco - similar = R$45,00\nIPhone 11PM preto - similar = R$45,00\nIPhone 11PM verde - similar = R$45,00\nIPhone 11PM gold - similar = R$45,00\nIPhone 12 mini branco - similar = R$50,00\nIPhone 12 mini preto - similar = R$50,00\nIPhone 12 mini azul - similar = R$50,00\nIPhone 12 mini verde - similar = R$50,00\nIPhone 12 branco - similar = R$50,00\nIPhone 12 preto - similar = R$50,00\nIPhone 12 lilás - similar = R$50,00\nIPhone 12 vermelho - similar = R$50,00\nIPhone 12 azul - similar = R$50,00\nIPhone 12 verde - similar = R$50,00\nIPhone 12 Pro branco - similar = R$50,00\nIPhone 12 Pro preto - similar = R$50,00\nIPhone 12 Pro azul - similar = R$50,00\nIPhone 12 Pro gold - similar = R$50,00\nIPhone 12PM branco - similar = R$50,00\nIPhone 12PM preto - similar = R$50,00\nIPhone 12PM azul - similar = R$50,00\nIPhone 12PM gold - similar = R$50,00\nIPhone 13 mini preto - similar = R$50,00\nIPhone 13 mini azul - similar = R$50,00\nIPhone 13 mini rosa - similar = R$50,00\nIPhone 13 mini vermelho - similar = R$50,00\nIPhone 13 mini verde - similar = R$50,00\nIPhone 13 branco - similar = R$50,00\nIPhone 13 preto - similar = R$50,00\nIPhone 13 azul - similar = R$50,00\nIPhone 13 rosa - similar = R$50,00\nIPhone 13 vermelho - similar = R$50,00\nIPhone 13 verde - similar = R$50,00\nIPhone 13 Pro branco - similar = R$50,00\nIPhone 13 Pro preto - similar = R$50,00\nIPhone 13 Pro verde - similar = R$50,00\nIPhone 13 Pro azul - similar = R$50,00\nIPhone 13 Pro gold - similar = R$50,00\nIPhone 13PM branco - similar = R$50,00\nIPhone 13PM preto - similar = R$50,00\nIPhone 13PM verde - similar = R$50,00\nIPhone 13PM azul - similar = R$50,00\nIPhone 13PM gold - similar = R$50,00\nIPhone 14 branco - similar com lentes = R$110,00\nIPhone 14 preto - similar com lentes = R$110,00\nIPhone 14 lilás - similar com lentes = R$110,00\nIPhone 14 azul - similar com lentes = R$110,00\nIPhone 14 vermelho - similar com lentes = R$110,00\nIPhone 14 amarelo - similar com lentes = R$110,00\nIPhone 14 Plus branco - similar com lentes = R$110,00\nIPhone 14 Plus preto - similar com lentes = R$110,00\nIPhone 14 Plus lilás - similar com lentes = R$110,00\nIPhone 14 Plus azul - similar com lentes = R$110,00\nIPhone 14 Pro branco - similar = R$50,00\nIPhone 14 Pro preto - similar = R$50,00\nIPhone 14 Pro roxo - similar = R$50,00\nIPhone 14 Pro gold - similar = R$50,00\nIPhone 14PM branco - similar = R$50,00\nIPhone 14PM preto - similar = R$50,00\nIPhone 14PM roxo - similar = R$50,00\nIPhone 15 preto - similar com lentes = R$120,00\nIPhone 15 verde - similar com lentes = R$120,00\nIPhone 15 rosa - similar com lentes = R$120,00\nIPhone 15 amarelo - similar com lentes = R$120,00\nIPhone 15 azul - similar com lentes = R$120,00\nIPhone 15 Plus preto - similar com lentes = R$120,00\nIPhone 15 Plus verde - similar com lentes = R$120,00\nIPhone 15 Plus azul - similar com lentes = R$120,00\nIPhone 15 Plus rosa - similar com lentes = R$120,00\nIPhone 15 Pro branco - similar com lentes = R$120,00\nIPhone 15 Pro preto - similar com lentes = R$120,00\nIPhone 15 Pro azul - similar com lentes = R$120,00\nIPhone 15PM preto - similar com lentes = R$120,00\nIPhone 12 Pro branco - original = R$90,00\nIPhone 12 Pro preto - original = R$90,00\nIPhone 12 Pro gold - original = R$90,00\nIPhone 12 Pro azul - original = R$90,00\nIPhone 12PM branco - original = R$90,00\nIPhone 12PM preto - original = R$90,00\nIPhone 12PM gold - original = R$90,00\nIPhone 12PM azul - original = R$90,00\nIPhone 13 Pro branco - original = R$90,00\nIPhone 13 Pro preto - original = R$90,00\nIPhone 13 Pro gold - original = R$90,00\nIPhone 13 Pro azul - original = R$90,00\nIPhone 13PM branco - original = R$90,00\nIPhone 13PM preto - original = R$90,00\nIPhone 13PM gold - original = R$90,00\nIPhone 13PM verde - original = R$90,00\nIPhone 14 preto - original = R$90,00\nIPhone 14 vermelho - original = R$90,00\nIPhone 14 azul - original = R$90,00\nIPhone 14 amarelo original = R$90,00\nIPhone 14 Pro branco - original = R$90,00\nIPhone 14 Pro preto - original = R$90,00\nIPhone 14 Pro gold - original = R$90,00\nIPhone 14 Pro roxo - original = R$90,00\nIPhone 15 Pro branco - original = R$180,00\nIPhone 15 Pro preto - original = R$180,00\nIPhone 15 Pro titanium - original = R$180,00\nIPhone 15 Pro azul - original = R$180,00\nIPhone 15PM branco - original = R$180,00\nIPhone 15PM preto - original = R$180,00\nIPhone 15PM titanium - original = R$180,00\nIPhone 15PM azul - original = R$180,00\nIPhone 16 branco - original = R$180,00\nIPhone 16 preto - original = R$180,00\nIPhone 16 verde - original = R$180,00\nIPhone 16 azul - original = R$180,00\nIPhone 16 rosa - original = R$180,00\nIPhone 16E branco - original = R$180,00\nIPhone 16E preto- original = R$180,00\nIPhone 16 Pro branco - original = R$180,00\nIPhone 16 Pro preto - original = R$180,00\nIPhone 16 Pro titanium - original = R$180,00\nIPhone 16 Pro desert - original = R$180,00\nIPhone 16PM branco - original = R$180,00\nIPhone 16PM preto - original = R$180,00\nIPhone 16PM titanium - original = R$180,00\nIPhone 16PM desert - original = R$180,00\nIPhone 17 verde - original = R$180,00\nIPhone 17 lilás - original = R$180,00\nIPhone 17 Pro branco - original = R$100,00\nIPhone 17 Pro laranja - original = R$100,00\nIPhone 17 Pro roxo - original = R$100,00\nIPhone 17PM branco - original = R$100,00\nIPhone 17PM laranja - original = R$100,00\nIPhone 17PM roxo - original = R$100,00','{\"intro\": [\"✔️\"], \"title\": \"Lista de Tampas\", \"brands\": [{\"name\": \"Geral\", \"devices\": [{\"name\": \"IPhone X preto - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone XS preto - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone XS gold - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone XS branco - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone XS MAX gold - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone XS MAX preto - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone XS MAX branco - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone XR preto - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone XR azul - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone XR vermelho - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone XR laranja - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone 8 gold - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone 8 branco - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone 8 preto - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone 8 vermelho - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone 8 plus gold - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone 8 plus branco - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone 8 plus vermelho - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone 8 plus preto - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone SE vermelho - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone SE preto - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone SE branco - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone 11 branco - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone 11 preto - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone 11 verde - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone 11 amarelo - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone 11 lilás - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone 11 vermelho - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$35,00\", \"priceValue\": 35}]}, {\"name\": \"IPhone 11 Pro branco - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$45,00\", \"priceValue\": 45}]}, {\"name\": \"IPhone 11 Pro preto - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$45,00\", \"priceValue\": 45}]}, {\"name\": \"IPhone 11 Pro verde - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$45,00\", \"priceValue\": 45}]}, {\"name\": \"IPhone 11 Pro gold - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$45,00\", \"priceValue\": 45}]}, {\"name\": \"IPhone 11PM branco - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$45,00\", \"priceValue\": 45}]}, {\"name\": \"IPhone 11PM preto - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$45,00\", \"priceValue\": 45}]}, {\"name\": \"IPhone 11PM verde - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$45,00\", \"priceValue\": 45}]}, {\"name\": \"IPhone 11PM gold - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$45,00\", \"priceValue\": 45}]}, {\"name\": \"IPhone 12 mini branco - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 12 mini preto - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 12 mini azul - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 12 mini verde - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 12 branco - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 12 preto - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 12 lilás - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 12 vermelho - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 12 azul - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 12 verde - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 12 Pro branco - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 12 Pro preto - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 12 Pro azul - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 12 Pro gold - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 12PM branco - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 12PM preto - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 12PM azul - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 12PM gold - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 13 mini preto - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 13 mini azul - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 13 mini rosa - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 13 mini vermelho - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 13 mini verde - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 13 branco - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 13 preto - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 13 azul - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 13 rosa - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 13 vermelho - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 13 verde - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 13 Pro branco - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 13 Pro preto - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 13 Pro verde - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 13 Pro azul - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 13 Pro gold - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 13PM branco - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 13PM preto - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 13PM verde - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 13PM azul - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 13PM gold - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 14 branco - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$110,00\", \"priceValue\": 110}]}, {\"name\": \"IPhone 14 preto - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$110,00\", \"priceValue\": 110}]}, {\"name\": \"IPhone 14 lilás - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$110,00\", \"priceValue\": 110}]}, {\"name\": \"IPhone 14 azul - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$110,00\", \"priceValue\": 110}]}, {\"name\": \"IPhone 14 vermelho - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$110,00\", \"priceValue\": 110}]}, {\"name\": \"IPhone 14 amarelo - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$110,00\", \"priceValue\": 110}]}, {\"name\": \"IPhone 14 Plus branco - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$110,00\", \"priceValue\": 110}]}, {\"name\": \"IPhone 14 Plus preto - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$110,00\", \"priceValue\": 110}]}, {\"name\": \"IPhone 14 Plus lilás - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$110,00\", \"priceValue\": 110}]}, {\"name\": \"IPhone 14 Plus azul - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$110,00\", \"priceValue\": 110}]}, {\"name\": \"IPhone 14 Pro branco - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 14 Pro preto - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 14 Pro roxo - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 14 Pro gold - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 14PM branco - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 14PM preto - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 14PM roxo - similar\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$50,00\", \"priceValue\": 50}]}, {\"name\": \"IPhone 15 preto - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$120,00\", \"priceValue\": 120}]}, {\"name\": \"IPhone 15 verde - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$120,00\", \"priceValue\": 120}]}, {\"name\": \"IPhone 15 rosa - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$120,00\", \"priceValue\": 120}]}, {\"name\": \"IPhone 15 amarelo - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$120,00\", \"priceValue\": 120}]}, {\"name\": \"IPhone 15 azul - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$120,00\", \"priceValue\": 120}]}, {\"name\": \"IPhone 15 Plus preto - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$120,00\", \"priceValue\": 120}]}, {\"name\": \"IPhone 15 Plus verde - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$120,00\", \"priceValue\": 120}]}, {\"name\": \"IPhone 15 Plus azul - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$120,00\", \"priceValue\": 120}]}, {\"name\": \"IPhone 15 Plus rosa - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$120,00\", \"priceValue\": 120}]}, {\"name\": \"IPhone 15 Pro branco - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$120,00\", \"priceValue\": 120}]}, {\"name\": \"IPhone 15 Pro preto - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$120,00\", \"priceValue\": 120}]}, {\"name\": \"IPhone 15 Pro azul - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$120,00\", \"priceValue\": 120}]}, {\"name\": \"IPhone 15PM preto - similar com lentes\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$120,00\", \"priceValue\": 120}]}, {\"name\": \"IPhone 12 Pro branco - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 12 Pro preto - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 12 Pro gold - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 12 Pro azul - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 12PM branco - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 12PM preto - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 12PM gold - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 12PM azul - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 13 Pro branco - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 13 Pro preto - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 13 Pro gold - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 13 Pro azul - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 13PM branco - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 13PM preto - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 13PM gold - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 13PM verde - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 14 preto - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 14 vermelho - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 14 azul - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 14 amarelo original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 14 Pro branco - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 14 Pro preto - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 14 Pro gold - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 14 Pro roxo - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$90,00\", \"priceValue\": 90}]}, {\"name\": \"IPhone 15 Pro branco - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 15 Pro preto - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 15 Pro titanium - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 15 Pro azul - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 15PM branco - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 15PM preto - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 15PM titanium - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 15PM azul - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 16 branco - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 16 preto - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 16 verde - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 16 azul - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 16 rosa - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 16E branco - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 16E preto- original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 16 Pro branco - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 16 Pro preto - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 16 Pro titanium - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 16 Pro desert - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 16PM branco - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 16PM preto - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 16PM titanium - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 16PM desert - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 17 verde - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 17 lilás - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$180,00\", \"priceValue\": 180}]}, {\"name\": \"IPhone 17 Pro branco - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 17 Pro laranja - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 17 Pro roxo - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 17PM branco - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 17PM laranja - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 17PM roxo - original\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}]}], \"categories\": [{\"name\": \"Geral\", \"items\": [{\"name\": \"IPhone X preto - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone XS preto - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone XS gold - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone XS branco - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone XS MAX gold - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone XS MAX preto - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone XS MAX branco - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone XR preto - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone XR azul - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone XR vermelho - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone XR laranja - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone 8 gold - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone 8 branco - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone 8 preto - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone 8 vermelho - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone 8 plus gold - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone 8 plus branco - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone 8 plus vermelho - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone 8 plus preto - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone SE vermelho - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone SE preto - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone SE branco - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone 11 branco - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone 11 preto - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone 11 verde - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone 11 amarelo - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone 11 lilás - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone 11 vermelho - similar\", \"priceText\": \"R$35,00\", \"priceValue\": 35}, {\"name\": \"IPhone 11 Pro branco - similar\", \"priceText\": \"R$45,00\", \"priceValue\": 45}, {\"name\": \"IPhone 11 Pro preto - similar\", \"priceText\": \"R$45,00\", \"priceValue\": 45}, {\"name\": \"IPhone 11 Pro verde - similar\", \"priceText\": \"R$45,00\", \"priceValue\": 45}, {\"name\": \"IPhone 11 Pro gold - similar\", \"priceText\": \"R$45,00\", \"priceValue\": 45}, {\"name\": \"IPhone 11PM branco - similar\", \"priceText\": \"R$45,00\", \"priceValue\": 45}, {\"name\": \"IPhone 11PM preto - similar\", \"priceText\": \"R$45,00\", \"priceValue\": 45}, {\"name\": \"IPhone 11PM verde - similar\", \"priceText\": \"R$45,00\", \"priceValue\": 45}, {\"name\": \"IPhone 11PM gold - similar\", \"priceText\": \"R$45,00\", \"priceValue\": 45}, {\"name\": \"IPhone 12 mini branco - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 12 mini preto - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 12 mini azul - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 12 mini verde - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 12 branco - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 12 preto - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 12 lilás - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 12 vermelho - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 12 azul - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 12 verde - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 12 Pro branco - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 12 Pro preto - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 12 Pro azul - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 12 Pro gold - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 12PM branco - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 12PM preto - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 12PM azul - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 12PM gold - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 13 mini preto - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 13 mini azul - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 13 mini rosa - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 13 mini vermelho - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 13 mini verde - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 13 branco - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 13 preto - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 13 azul - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 13 rosa - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 13 vermelho - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 13 verde - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 13 Pro branco - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 13 Pro preto - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 13 Pro verde - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 13 Pro azul - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 13 Pro gold - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 13PM branco - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 13PM preto - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 13PM verde - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 13PM azul - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 13PM gold - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 14 branco - similar com lentes\", \"priceText\": \"R$110,00\", \"priceValue\": 110}, {\"name\": \"IPhone 14 preto - similar com lentes\", \"priceText\": \"R$110,00\", \"priceValue\": 110}, {\"name\": \"IPhone 14 lilás - similar com lentes\", \"priceText\": \"R$110,00\", \"priceValue\": 110}, {\"name\": \"IPhone 14 azul - similar com lentes\", \"priceText\": \"R$110,00\", \"priceValue\": 110}, {\"name\": \"IPhone 14 vermelho - similar com lentes\", \"priceText\": \"R$110,00\", \"priceValue\": 110}, {\"name\": \"IPhone 14 amarelo - similar com lentes\", \"priceText\": \"R$110,00\", \"priceValue\": 110}, {\"name\": \"IPhone 14 Plus branco - similar com lentes\", \"priceText\": \"R$110,00\", \"priceValue\": 110}, {\"name\": \"IPhone 14 Plus preto - similar com lentes\", \"priceText\": \"R$110,00\", \"priceValue\": 110}, {\"name\": \"IPhone 14 Plus lilás - similar com lentes\", \"priceText\": \"R$110,00\", \"priceValue\": 110}, {\"name\": \"IPhone 14 Plus azul - similar com lentes\", \"priceText\": \"R$110,00\", \"priceValue\": 110}, {\"name\": \"IPhone 14 Pro branco - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 14 Pro preto - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 14 Pro roxo - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 14 Pro gold - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 14PM branco - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 14PM preto - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 14PM roxo - similar\", \"priceText\": \"R$50,00\", \"priceValue\": 50}, {\"name\": \"IPhone 15 preto - similar com lentes\", \"priceText\": \"R$120,00\", \"priceValue\": 120}, {\"name\": \"IPhone 15 verde - similar com lentes\", \"priceText\": \"R$120,00\", \"priceValue\": 120}, {\"name\": \"IPhone 15 rosa - similar com lentes\", \"priceText\": \"R$120,00\", \"priceValue\": 120}, {\"name\": \"IPhone 15 amarelo - similar com lentes\", \"priceText\": \"R$120,00\", \"priceValue\": 120}, {\"name\": \"IPhone 15 azul - similar com lentes\", \"priceText\": \"R$120,00\", \"priceValue\": 120}, {\"name\": \"IPhone 15 Plus preto - similar com lentes\", \"priceText\": \"R$120,00\", \"priceValue\": 120}, {\"name\": \"IPhone 15 Plus verde - similar com lentes\", \"priceText\": \"R$120,00\", \"priceValue\": 120}, {\"name\": \"IPhone 15 Plus azul - similar com lentes\", \"priceText\": \"R$120,00\", \"priceValue\": 120}, {\"name\": \"IPhone 15 Plus rosa - similar com lentes\", \"priceText\": \"R$120,00\", \"priceValue\": 120}, {\"name\": \"IPhone 15 Pro branco - similar com lentes\", \"priceText\": \"R$120,00\", \"priceValue\": 120}, {\"name\": \"IPhone 15 Pro preto - similar com lentes\", \"priceText\": \"R$120,00\", \"priceValue\": 120}, {\"name\": \"IPhone 15 Pro azul - similar com lentes\", \"priceText\": \"R$120,00\", \"priceValue\": 120}, {\"name\": \"IPhone 15PM preto - similar com lentes\", \"priceText\": \"R$120,00\", \"priceValue\": 120}, {\"name\": \"IPhone 12 Pro branco - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 12 Pro preto - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 12 Pro gold - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 12 Pro azul - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 12PM branco - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 12PM preto - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 12PM gold - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 12PM azul - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 13 Pro branco - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 13 Pro preto - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 13 Pro gold - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 13 Pro azul - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 13PM branco - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 13PM preto - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 13PM gold - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 13PM verde - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 14 preto - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 14 vermelho - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 14 azul - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 14 amarelo original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 14 Pro branco - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 14 Pro preto - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 14 Pro gold - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 14 Pro roxo - original\", \"priceText\": \"R$90,00\", \"priceValue\": 90}, {\"name\": \"IPhone 15 Pro branco - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 15 Pro preto - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 15 Pro titanium - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 15 Pro azul - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 15PM branco - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 15PM preto - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 15PM titanium - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 15PM azul - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 16 branco - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 16 preto - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 16 verde - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 16 azul - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 16 rosa - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 16E branco - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 16E preto- original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 16 Pro branco - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 16 Pro preto - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 16 Pro titanium - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 16 Pro desert - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 16PM branco - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 16PM preto - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 16PM titanium - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 16PM desert - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 17 verde - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 17 lilás - original\", \"priceText\": \"R$180,00\", \"priceValue\": 180}, {\"name\": \"IPhone 17 Pro branco - original\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 17 Pro laranja - original\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 17 Pro roxo - original\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 17PM branco - original\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 17PM laranja - original\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 17PM roxo - original\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}], \"effectiveDate\": \"10/04/26\"}','[]',NULL,NULL,'2026-04-27 15:07:59','2026-04-27 15:18:24'),(3,'lista-de-veda-o','Lista de Vedaçao','27/04/2026',1,0,3,'Lista de Vedação: 27/04/2026\n🔧\nIPhone 12PM = R$100,00\nIPhone 13 = R$100,00\nIPhone 13 Pro = R$100,00\nIPhone 13PM = R$100,00\nIPhone 14 = R$100,00\nIPhone 14 Pro = R$100,00\nIPhone 14PM = R$100,00\nIPhone 15 = R$100,00\nIPhone 15 Pro = R$100,00\nIPhone 15PM = R$100,00\nIPhone 16 Pro = R$100,00\nIPhone 16PM = R$100,00\nIPhone 17 Pro = R$100,00\nIPhone 17PM = R$100,00','{\"intro\": [\"🔧\"], \"title\": \"Lista de Vedaçao\", \"brands\": [{\"name\": \"Geral\", \"devices\": [{\"name\": \"IPhone 12PM\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 13\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 13 Pro\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 13PM\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 14\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 14 Pro\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 14PM\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 15\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 15 Pro\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 15PM\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 16 Pro\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 16PM\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 17 Pro\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}, {\"name\": \"IPhone 17PM\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}]}], \"categories\": [{\"name\": \"Geral\", \"items\": [{\"name\": \"IPhone 12PM\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 13\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 13 Pro\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 13PM\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 14\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 14 Pro\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 14PM\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 15\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 15 Pro\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 15PM\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 16 Pro\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 16PM\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 17 Pro\", \"priceText\": \"R$100,00\", \"priceValue\": 100}, {\"name\": \"IPhone 17PM\", \"priceText\": \"R$100,00\", \"priceValue\": 100}]}], \"effectiveDate\": \"27/04/2026\"}','[]',NULL,NULL,'2026-04-27 15:09:21','2026-04-27 15:20:00'),(5,'lista-de-manuten-o-baterias','Lista de Manutenção Baterias','27/04/2026',1,0,4,'lista de manutenção baterias: 27/04/2026\n\n🔋\n\nIPhone 12 PM = R$240,00\nIPhone 13 = R$230,00\nIPhone 13 Pro = R$240,00\nIPhone 13 PM = R$250,00\nIPhone 14 = R$230,00\nIPhone 14 Pro = R$240,00\nIPhone 14 PM = R$250,00\nIPhone 15 = R$290,00\nIPhone 15 Pro = R$300,00\nIPhone 15 PM = R$310,00\nIPhone 16 = R$350,00\nIPhone 16 Pro = R$350,00\nIPhone 16 PM = R$350,00','{\"intro\": [\"🔋\"], \"title\": \"Lista de Manutenção Baterias\", \"brands\": [{\"name\": \"Geral\", \"devices\": [{\"name\": \"IPhone 12 PM\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$240,00\", \"priceValue\": 240}]}, {\"name\": \"IPhone 13\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$230,00\", \"priceValue\": 230}]}, {\"name\": \"IPhone 13 Pro\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$240,00\", \"priceValue\": 240}]}, {\"name\": \"IPhone 13 PM\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$250,00\", \"priceValue\": 250}]}, {\"name\": \"IPhone 14\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$230,00\", \"priceValue\": 230}]}, {\"name\": \"IPhone 14 Pro\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$240,00\", \"priceValue\": 240}]}, {\"name\": \"IPhone 14 PM\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$250,00\", \"priceValue\": 250}]}, {\"name\": \"IPhone 15\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$290,00\", \"priceValue\": 290}]}, {\"name\": \"IPhone 15 Pro\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$300,00\", \"priceValue\": 300}]}, {\"name\": \"IPhone 15 PM\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$310,00\", \"priceValue\": 310}]}, {\"name\": \"IPhone 16\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$350,00\", \"priceValue\": 350}]}, {\"name\": \"IPhone 16 Pro\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$350,00\", \"priceValue\": 350}]}, {\"name\": \"IPhone 16 PM\", \"services\": [{\"name\": \"Preco base\", \"priceText\": \"R$350,00\", \"priceValue\": 350}]}]}], \"categories\": [{\"name\": \"Geral\", \"items\": [{\"name\": \"IPhone 12 PM\", \"priceText\": \"R$240,00\", \"priceValue\": 240}, {\"name\": \"IPhone 13\", \"priceText\": \"R$230,00\", \"priceValue\": 230}, {\"name\": \"IPhone 13 Pro\", \"priceText\": \"R$240,00\", \"priceValue\": 240}, {\"name\": \"IPhone 13 PM\", \"priceText\": \"R$250,00\", \"priceValue\": 250}, {\"name\": \"IPhone 14\", \"priceText\": \"R$230,00\", \"priceValue\": 230}, {\"name\": \"IPhone 14 Pro\", \"priceText\": \"R$240,00\", \"priceValue\": 240}, {\"name\": \"IPhone 14 PM\", \"priceText\": \"R$250,00\", \"priceValue\": 250}, {\"name\": \"IPhone 15\", \"priceText\": \"R$290,00\", \"priceValue\": 290}, {\"name\": \"IPhone 15 Pro\", \"priceText\": \"R$300,00\", \"priceValue\": 300}, {\"name\": \"IPhone 15 PM\", \"priceText\": \"R$310,00\", \"priceValue\": 310}, {\"name\": \"IPhone 16\", \"priceText\": \"R$350,00\", \"priceValue\": 350}, {\"name\": \"IPhone 16 Pro\", \"priceText\": \"R$350,00\", \"priceValue\": 350}, {\"name\": \"IPhone 16 PM\", \"priceText\": \"R$350,00\", \"priceValue\": 350}]}], \"effectiveDate\": \"27/04/2026\"}','[]',NULL,NULL,'2026-04-27 15:11:12','2026-04-27 15:22:53');
/*!40000 ALTER TABLE `retailer_price_tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `retailers`
--

DROP TABLE IF EXISTS `retailers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `retailers` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnpj` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('retailer','admin') COLLATE utf8mb4_unicode_ci DEFAULT 'retailer',
  `active` tinyint(1) DEFAULT '1',
  `approval_status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `approved_at` timestamp NULL DEFAULT NULL,
  `approved_by` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_email` (`email`),
  KEY `idx_active` (`active`),
  KEY `idx_approval_status` (`approval_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `retailers`
--

LOCK TABLES `retailers` WRITE;
/*!40000 ALTER TABLE `retailers` DISABLE KEYS */;
INSERT INTO `retailers` VALUES ('retailer-1777319857396-otyscwrak','user@donassistec.com','$2b$10$8lNeXmNgCbbWmtNw/Gwgs.BNgrBhu3ir.uMYI2nEx9TaK76cEJtQm','teste','teste','(51) 99130-2223',NULL,'retailer',1,'approved','2026-04-27 19:58:16','ateam-1777299498342-grn1y51f','2026-04-27 19:57:37','2026-04-27 19:58:16');
/*!40000 ALTER TABLE `retailers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_types`
--

DROP TABLE IF EXISTS `service_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_types` (
  `id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_types`
--

LOCK TABLES `service_types` WRITE;
/*!40000 ALTER TABLE `service_types` DISABLE KEYS */;
INSERT INTO `service_types` VALUES ('glassReplacement','Troca de Vidro','ðŸªŸ','SubstituiÃ§Ã£o apenas do vidro frontal','2026-04-27 12:29:29'),('partsAvailable','PeÃ§as DisponÃ­veis','ðŸ“¦','CatÃ¡logo completo de peÃ§as originais e compatÃ­veis','2026-04-27 12:29:29'),('reconstruction','ReconstruÃ§Ã£o de Tela','ðŸ”§','Processo industrial com mÃ¡quinas de Ãºltima geraÃ§Ã£o','2026-04-27 12:29:29');
/*!40000 ALTER TABLE `service_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_services_active` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES ('service_battery','Troca de Bateria','SubstituiÃ§Ã£o da bateria',1,'2026-04-27 12:31:42','2026-04-27 12:31:42'),('service_camera','Reparo de Câmera','Reparo ou substituiÃ§Ã£o de cÃ¢mera',1,'2026-04-27 12:31:42','2026-04-27 12:31:43'),('service_charging','Reparo de Carregamento','Reparo do sistema de carregamento',1,'2026-04-27 12:31:42','2026-04-27 12:31:42'),('service_glass','Troca de Vidro','Troca de vidro da tela',1,'2026-04-27 12:31:42','2026-04-27 12:31:42'),('service_parts','Peças Disponíveis','PeÃ§as disponÃ­veis para reposiÃ§Ã£o',1,'2026-04-27 12:31:42','2026-04-27 12:31:43'),('service_reconstruction','Reconstrução','ServiÃ§o de reconstruÃ§Ã£o completa do aparelho',1,'2026-04-27 12:31:42','2026-04-27 12:31:43'),('service_screen','Troca de Tela','SubstituiÃ§Ã£o completa da tela',1,'2026-04-27 12:31:42','2026-04-27 12:31:42'),('service_software','Atualização/Formatação','AtualizaÃ§Ã£o de software ou formataÃ§Ã£o',1,'2026-04-27 12:31:42','2026-04-27 12:31:43');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings_history`
--

DROP TABLE IF EXISTS `settings_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `old_value` text,
  `new_value` text,
  `changed_by` varchar(255) NOT NULL,
  `changed_by_email` varchar(255) DEFAULT NULL,
  `changed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_settings_history_key` (`setting_key`),
  KEY `idx_settings_history_changed_at` (`changed_at`),
  KEY `idx_settings_history_changed_by` (`changed_by`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings_history`
--

LOCK TABLES `settings_history` WRITE;
/*!40000 ALTER TABLE `settings_history` DISABLE KEYS */;
INSERT INTO `settings_history` VALUES (1,'showNavHome',NULL,'true','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 14:10:29'),(2,'showNavCatalog',NULL,'false','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 14:10:29'),(3,'showNavFavorites',NULL,'false','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 14:10:29'),(4,'showNavAbout',NULL,'true','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 14:10:29'),(5,'showNavHelp',NULL,'true','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 14:10:29'),(6,'showNavServices',NULL,'false','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 14:10:29'),(7,'showNavBrands',NULL,'true','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 14:10:29'),(8,'showNavContact',NULL,'false','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 14:10:29'),(9,'showAdminAccessButton',NULL,'false','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 14:10:29'),(10,'showHeaderPhone',NULL,'false','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 14:10:29'),(11,'showRetailerAreaButton',NULL,'true','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 14:10:29'),(12,'showNavBrands','true','false','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 14:11:13'),(13,'brandingLogoUrl',NULL,'https://donassistec.com.br/uploads/image-1777299101538-391228312.jpeg','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 14:11:49'),(14,'brandingLogoFavicon',NULL,'https://donassistec.com.br/uploads/image-1777299105699-256901815.jpeg','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 14:11:49'),(15,'showCompanyTradeName',NULL,'true','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 14:12:22'),(16,'showCompanyTradeNameHeader',NULL,'false','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 14:12:22'),(17,'showCompanyTradeNameFooter',NULL,'false','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 14:12:22'),(18,'showCompanySloganFooter',NULL,'false','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 14:12:22'),(19,'retailerTrainingVideos',NULL,'[{\"id\":\"video-1777319559983-0\",\"title\":\"Troca de tela\",\"description\":\"\",\"url\":\"https://www.instagram.com/don.assistec/reel/DWy0fs-Ey9f/\",\"thumbnail\":\"https://donassistec.com.br/uploads/image-1777319572233-956284936.jpeg\",\"duration\":\"\",\"category\":\"Reparos\",\"order\":0,\"published\":true}]','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 19:55:12'),(20,'contactAddress',NULL,'Rua Curitiba, 611','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 20:03:56'),(21,'contactCep',NULL,'94955-130','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 20:03:56'),(22,'contactCity',NULL,'Cachoeirinha','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 20:03:56'),(23,'contactState',NULL,'RS','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 20:03:56'),(24,'socialInstagram',NULL,'https://www.instagram.com/don.assistec/','ateam-1777296113832-0wsshphc','ronei@donassistec.com','2026-04-27 20:07:35');
/*!40000 ALTER TABLE `settings_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_tickets`
--

DROP TABLE IF EXISTS `support_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_tickets` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `retailer_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('open','in_progress','resolved','closed') COLLATE utf8mb4_unicode_ci DEFAULT 'open',
  `priority` enum('low','medium','high','urgent') COLLATE utf8mb4_unicode_ci DEFAULT 'medium',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_retailer` (`retailer_id`),
  KEY `idx_status` (`status`),
  KEY `idx_priority` (`priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_tickets`
--

LOCK TABLES `support_tickets` WRITE;
/*!40000 ALTER TABLE `support_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_value` text COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES ('allow-retailer-registration','allowRetailerRegistration','true','Permitir cadastro de lojistas (true/false)','2026-04-27 12:41:43','2026-04-27 14:10:07'),('api-rate-limit','apiRateLimit','100','Limite de requisições API por minuto','2026-04-27 12:41:43','2026-04-27 12:41:43'),('auto-approve-payment','autoApprovePayment','false','Aprovar pagamentos automaticamente','2026-04-27 12:41:43','2026-04-27 12:41:43'),('branding-logo-favicon','brandingLogoFavicon','https://donassistec.com.br/uploads/image-1777299105699-256901815.jpeg','URL do favicon','2026-04-27 12:41:43','2026-04-27 14:11:49'),('branding-logo-url','brandingLogoUrl','https://donassistec.com.br/uploads/image-1777299101538-391228312.jpeg','URL do logo da empresa','2026-04-27 12:41:43','2026-04-27 14:11:49'),('branding-primary-color','brandingPrimaryColor','#6366f1','Cor primária da marca (hex)','2026-04-27 12:41:43','2026-04-27 14:11:49'),('branding-secondary-color','brandingSecondaryColor','#8b5cf6','Cor secundária da marca (hex)','2026-04-27 12:41:43','2026-04-27 14:11:49'),('cache-duration','cacheDuration','300','Duração do cache em segundos','2026-04-27 12:41:43','2026-04-27 12:41:43'),('cache-enabled','cacheEnabled','true','Habilitar cache','2026-04-27 12:41:43','2026-04-27 12:41:43'),('company-cnpj','companyCnpj','','CNPJ da empresa','2026-04-27 12:41:43','2026-04-27 14:12:23'),('company-description','companyDescription','Laboratório premium de reconstrução de telas e revenda de peças para lojistas e assistências técnicas.','Descrição da empresa','2026-04-27 12:41:43','2026-04-27 14:12:23'),('company-fac','companyFac','','FAC (Fundo de Aperfeiçoamento Científico ou outro)','2026-04-27 12:41:43','2026-04-27 14:12:23'),('company-ie','companyIe','','Inscrição Estadual','2026-04-27 12:41:43','2026-04-27 14:12:23'),('company-im','companyIm','','Inscrição Municipal','2026-04-27 12:41:43','2026-04-27 14:12:23'),('company-legal-name','companyLegalName','','Razão Social da empresa','2026-04-27 12:41:43','2026-04-27 14:12:23'),('company-slogan','companySlogan','','Slogan da empresa','2026-04-27 12:41:43','2026-04-27 14:12:23'),('company-trade-name','companyTradeName','DonAssistec','Nome Fantasia','2026-04-27 12:41:43','2026-04-27 14:12:23'),('company-website','companyWebsite','','Website da empresa (.com, etc)','2026-04-27 12:41:43','2026-04-27 14:12:23'),('company-year-founded','companyYearFounded','','Ano de fundação','2026-04-27 12:41:43','2026-04-27 14:12:23'),('contact-address','contactAddress','Rua Curitiba, 611','Endereço da empresa','2026-04-27 12:41:43','2026-04-27 20:03:59'),('contact-cep','contactCep','94955-130','CEP do endereço','2026-04-27 12:41:43','2026-04-27 20:03:59'),('contact-city','contactCity','Cachoeirinha','Cidade','2026-04-27 12:41:43','2026-04-27 20:03:59'),('contact-email','contactEmail','contato@donassistec.com.br','E-mail de contato','2026-04-27 12:41:43','2026-04-27 20:03:59'),('contact-phone','contactPhone','','Telefone de contato principal','2026-04-27 12:41:43','2026-04-27 20:03:59'),('contact-phone-raw','contactPhoneRaw','','Telefone em formato raw (sem formatação)','2026-04-27 12:41:43','2026-04-27 20:03:59'),('contact-state','contactState','RS','Estado','2026-04-27 12:41:43','2026-04-27 20:03:59'),('contact-whatsapp','contactWhatsApp','','WhatsApp para Fale Conosco (pode ser diferente do WhatsApp de integração)','2026-04-27 12:41:43','2026-04-27 20:03:59'),('email-notifications','emailNotifications','true','Notificações por email (true/false)','2026-04-27 12:41:43','2026-04-27 12:41:43'),('facebook-pixel-id','facebookPixelId','','ID Facebook Pixel','2026-04-27 12:41:43','2026-04-27 12:41:43'),('google-analytics-id','googleAnalyticsId','','ID Google Analytics','2026-04-27 12:41:43','2026-04-27 12:41:43'),('image-optimization','imageOptimization','true','Otimização automática de imagens','2026-04-27 12:41:43','2026-04-27 12:41:43'),('maintenance-mode','maintenanceMode','false','Modo de manutenção (true/false)','2026-04-27 12:41:43','2026-04-27 14:10:07'),('max-login-attempts','maxLoginAttempts','5','Máximo de tentativas de login','2026-04-27 12:41:43','2026-04-27 12:41:43'),('max-orders-per-day','maxOrdersPerDay','100','Máximo de pedidos por dia','2026-04-27 12:41:43','2026-04-27 14:10:07'),('max-upload-size','maxUploadSize','5242880','Tamanho máximo de upload em bytes (5MB)','2026-04-27 12:41:43','2026-04-27 12:41:43'),('notification-email-template','notificationEmailTemplate','default','Template de email de notificações','2026-04-27 12:41:43','2026-04-27 12:41:43'),('notify-low-stock','notifyLowStock','true','Notificar estoque baixo','2026-04-27 12:41:43','2026-04-27 12:41:43'),('notify-new-order','notifyNewOrder','true','Notificar novos pedidos','2026-04-27 12:41:43','2026-04-27 12:41:43'),('notify-new-ticket','notifyNewTicket','true','Notificar novos tickets','2026-04-27 12:41:43','2026-04-27 12:41:43'),('notify-order-status','notifyOrderStatus','true','Notificar mudanças de status','2026-04-27 12:41:43','2026-04-27 12:41:43'),('notify-ticket-reply','notifyTicketReply','true','Notificar respostas de tickets','2026-04-27 12:41:43','2026-04-27 12:41:43'),('password-min-length','passwordMinLength','8','Tamanho mínimo de senha','2026-04-27 12:41:43','2026-04-27 12:41:43'),('password-require-numbers','passwordRequireNumbers','true','Exigir números na senha','2026-04-27 12:41:43','2026-04-27 12:41:43'),('password-require-symbols','passwordRequireSymbols','false','Exigir símbolos na senha','2026-04-27 12:41:43','2026-04-27 12:41:43'),('password-require-uppercase','passwordRequireUppercase','true','Exigir letra maiúscula na senha','2026-04-27 12:41:43','2026-04-27 12:41:43'),('payment-bank-account','paymentBankAccount','','Conta bancária','2026-04-27 12:41:43','2026-04-27 12:41:43'),('payment-bank-agency','paymentBankAgency','','Agência bancária','2026-04-27 12:41:43','2026-04-27 12:41:43'),('payment-bank-name','paymentBankName','','Nome do banco','2026-04-27 12:41:43','2026-04-27 12:41:43'),('payment-methods','paymentMethods','bank_transfer,pix','Métodos de pagamento aceitos','2026-04-27 12:41:43','2026-04-27 12:41:43'),('payment-pix-key','paymentPixKey','','Chave PIX','2026-04-27 12:41:43','2026-04-27 12:41:43'),('payment-pix-key-type','paymentPixKeyType','email','Tipo de chave PIX (email/cpf/cnpj/random)','2026-04-27 12:41:43','2026-04-27 12:41:43'),('require-email-verification','requireEmailVerification','false','Exigir verificação de email','2026-04-27 12:41:43','2026-04-27 12:41:43'),('retailer-training-videos','retailerTrainingVideos','[{\"id\":\"video-1777319559983-0\",\"title\":\"Troca de tela\",\"description\":\"\",\"url\":\"https://www.instagram.com/don.assistec/reel/DWy0fs-Ey9f/\",\"thumbnail\":\"https://donassistec.com.br/uploads/image-1777319572233-956284936.jpeg\",\"duration\":\"\",\"category\":\"Reparos\",\"order\":0,\"published\":true}]','JSON com vídeos explicativos exibidos na área do lojista','2026-04-27 19:55:12','2026-04-27 19:55:12'),('seo-description','seoDescription','Catálogo B2B de peças e serviços para celulares','Descrição SEO','2026-04-27 12:41:43','2026-04-27 12:41:43'),('seo-keywords','seoKeywords','peças celular, reconstrução tela, assistência técnica','Palavras-chave SEO','2026-04-27 12:41:43','2026-04-27 12:41:43'),('seo-og-image','seoOgImage','','Imagem Open Graph','2026-04-27 12:41:43','2026-04-27 12:41:43'),('seo-title','seoTitle','DonAssistec - Reconstrução de Telas e Peças','Título SEO','2026-04-27 12:41:43','2026-04-27 12:41:43'),('session-timeout','sessionTimeout','3600','Timeout de sessão em segundos','2026-04-27 12:41:43','2026-04-27 12:41:43'),('show-admin-access-button','showAdminAccessButton','false','Exibir ícone Admin no cabeçalho','2026-04-27 14:10:29','2026-04-27 14:11:13'),('show-company-slogan-footer','showCompanySloganFooter','false','Exibir slogan no rodapé público','2026-04-27 14:12:22','2026-04-27 14:12:23'),('show-company-trade-name','showCompanyTradeName','true','Exibir nome fantasia no cabeçalho e rodapé público','2026-04-27 14:12:22','2026-04-27 14:12:23'),('show-company-trade-name-footer','showCompanyTradeNameFooter','false','Exibir nome fantasia no rodapé público','2026-04-27 14:12:22','2026-04-27 14:12:23'),('show-company-trade-name-header','showCompanyTradeNameHeader','false','Exibir nome fantasia no cabeçalho público','2026-04-27 14:12:22','2026-04-27 14:12:23'),('show-header-phone','showHeaderPhone','false','Exibir telefone no cabeçalho','2026-04-27 14:10:29','2026-04-27 14:11:13'),('show-nav-about','showNavAbout','true','Exibir link Sobre no menu principal','2026-04-27 14:10:29','2026-04-27 14:11:13'),('show-nav-brands','showNavBrands','false','Exibir link Marcas no menu principal','2026-04-27 14:10:29','2026-04-27 14:11:13'),('show-nav-catalog','showNavCatalog','false','Exibir link Catálogo no menu principal','2026-04-27 14:10:29','2026-04-27 14:11:13'),('show-nav-contact','showNavContact','false','Exibir link Contato no menu principal','2026-04-27 14:10:29','2026-04-27 14:11:13'),('show-nav-favorites','showNavFavorites','false','Exibir link Favoritos no menu principal','2026-04-27 14:10:29','2026-04-27 14:11:13'),('show-nav-help','showNavHelp','true','Exibir link Ajuda no menu principal','2026-04-27 14:10:29','2026-04-27 14:11:13'),('show-nav-home','showNavHome','true','Exibir link Home no menu principal','2026-04-27 14:10:29','2026-04-27 14:11:13'),('show-nav-services','showNavServices','false','Exibir link Serviços no menu principal','2026-04-27 14:10:29','2026-04-27 14:11:13'),('show-retailer-area-button','showRetailerAreaButton','true','Exibir botão Área do Lojista no cabeçalho','2026-04-27 14:10:29','2026-04-27 14:11:13'),('site-description','siteDescription','Catálogo B2B de peças e serviços para celulares','Descrição do site','2026-04-27 12:41:43','2026-04-27 14:10:09'),('site-name','siteName','DonAssistec','Nome do site','2026-04-27 12:41:43','2026-04-27 14:10:09'),('site-url','siteUrl','https://donassistec.com','URL do site','2026-04-27 12:41:43','2026-04-27 14:10:09'),('sms-notifications','smsNotifications','false','Notificações por SMS (true/false)','2026-04-27 12:41:43','2026-04-27 12:41:43'),('smtp-from-email','smtpFromEmail','noreply@donassistec.com','Email remetente padrão','2026-04-27 12:41:43','2026-04-27 12:41:43'),('smtp-from-name','smtpFromName','DonAssistec','Nome remetente padrão','2026-04-27 12:41:43','2026-04-27 12:41:43'),('smtp-host','smtpHost','smtp.gmail.com','Servidor SMTP','2026-04-27 12:41:43','2026-04-27 12:41:43'),('smtp-password','smtpPassword','','Senha SMTP','2026-04-27 12:41:43','2026-04-27 12:41:43'),('smtp-port','smtpPort','587','Porta SMTP','2026-04-27 12:41:43','2026-04-27 12:41:43'),('smtp-secure','smtpSecure','true','Conexão segura SMTP (true/false)','2026-04-27 12:41:43','2026-04-27 12:41:43'),('smtp-user','smtpUser','','Usuário SMTP','2026-04-27 12:41:43','2026-04-27 12:41:43'),('social-facebook','socialFacebook','','URL do perfil do Facebook','2026-04-27 12:41:43','2026-04-27 20:07:35'),('social-instagram','socialInstagram','https://www.instagram.com/don.assistec/','URL do perfil do Instagram','2026-04-27 12:41:43','2026-04-27 20:07:35'),('social-linkedin','socialLinkedin','','URL do perfil do LinkedIn','2026-04-27 12:41:43','2026-04-27 20:07:35'),('social-tiktok','socialTikTok','','URL do perfil do TikTok','2026-04-27 12:41:43','2026-04-27 20:07:35'),('social-twitter','socialTwitter','','URL do perfil do Twitter/X','2026-04-27 12:41:43','2026-04-27 20:07:35'),('social-youtube','socialYoutube','','URL do canal do YouTube','2026-04-27 12:41:43','2026-04-27 20:07:35'),('support-email','supportEmail','suporte@donassistec.com','Email de suporte','2026-04-27 12:41:43','2026-04-27 12:41:43'),('support-phone','supportPhone','','Telefone de suporte','2026-04-27 12:41:43','2026-04-27 12:55:42'),('two-factor-auth','twoFactorAuth','false','Autenticação de dois fatores','2026-04-27 12:41:43','2026-04-27 12:41:43'),('whatsapp-api-key','whatsappApiKey','','Chave API WhatsApp','2026-04-27 12:41:43','2026-04-27 12:41:43'),('whatsapp-contact-message','whatsappContactMessage','Olá! Sou lojista e gostaria de saber mais sobre peças e serviços da DonAssistec.','Mensagem padrão para contato via WhatsApp','2026-04-27 12:41:43','2026-04-27 20:03:59'),('whatsapp-enabled','whatsappEnabled','true','Habilitar integração WhatsApp','2026-04-27 12:41:43','2026-04-27 12:41:43'),('whatsapp-number','whatsappNumber','','Número WhatsApp (com código do país)','2026-04-27 12:41:43','2026-04-27 12:41:43');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_messages`
--

DROP TABLE IF EXISTS `ticket_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_messages` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ticket_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_type` enum('retailer','admin') COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ticket` (`ticket_id`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `ticket_messages_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `support_tickets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_messages`
--

LOCK TABLES `ticket_messages` WRITE;
/*!40000 ALTER TABLE `ticket_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_messages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-28  1:33:31
